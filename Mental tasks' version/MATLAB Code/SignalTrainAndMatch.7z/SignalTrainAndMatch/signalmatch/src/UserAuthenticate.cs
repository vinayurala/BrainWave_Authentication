/*
* MATLAB Compiler: 4.11 (R2009b)
* Date: Thu May 06 22:11:51 2010
* Arguments: "-B" "macro_default" "-W" "dotnet:signalmatch,UserAuthenticate,0.0,private"
* "-d" "C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signalmatch\src" "-T"
* "link:lib" "-v" "class{UserAuthenticate:C:\Documents and Settings\KrishSuk\My
* Documents\MATLAB\signal match (dharini) modified\channel_spectral_power.m,C:\Documents
* and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
* modified\feature_extract1.m,C:\Documents and Settings\KrishSuk\My
* Documents\MATLAB\signal match (dharini)
* modified\inter_hem_channel_spec_pow_diff.m,C:\Documents and Settings\KrishSuk\My
* Documents\MATLAB\signal match (dharini) modified\loadcsv.m,C:\Documents and
* Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
* modified\match.m,C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match
* (dharini) modified\storeNewFeature.m}" 
*/
using System;
using System.Reflection;
using System.IO;
using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;
using MathWorks.MATLAB.NET.ComponentData;

#if SHARED
[assembly: System.Reflection.AssemblyKeyFile(@"")]
#endif

namespace signalmatch
{
  /// <summary>
  /// The UserAuthenticate class provides a CLS compliant, MWArray interface to the
  /// M-functions contained in the files:
  /// <newpara></newpara>
  /// C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
  /// modified\channel_spectral_power.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
  /// modified\feature_extract1.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
  /// modified\inter_hem_channel_spec_pow_diff.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
  /// modified\loadcsv.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
  /// modified\match.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\KrishSuk\My Documents\MATLAB\signal match (dharini)
  /// modified\storeNewFeature.m
  /// <newpara></newpara>
  /// deployprint.m
  /// <newpara></newpara>
  /// printdlg.m
  /// </summary>
  /// <remarks>
  /// @Version 0.0
  /// </remarks>
  public class UserAuthenticate : IDisposable
  {
    #region Constructors

    /// <summary internal= "true">
    /// The static constructor instantiates and initializes the MATLAB Component Runtime
    /// instance.
    /// </summary>
    static UserAuthenticate()
    {
      if (MWMCR.MCRAppInitialized)
      {
        Assembly assembly= Assembly.GetExecutingAssembly();

        string ctfFilePath= assembly.Location;

        int lastDelimiter= ctfFilePath.LastIndexOf(@"\");

        ctfFilePath= ctfFilePath.Remove(lastDelimiter, (ctfFilePath.Length - lastDelimiter));

        string ctfFileName = MCRComponentState.MCC_signalmatch_name_data + ".ctf";

        Stream embeddedCtfStream = null;

        String[] resourceStrings = assembly.GetManifestResourceNames();

        foreach (String name in resourceStrings)
        {
          if (name.Contains(ctfFileName))
          {
            embeddedCtfStream = assembly.GetManifestResourceStream(name);
            break;
          }
        }
        mcr= new MWMCR(MCRComponentState.MCC_signalmatch_name_data,
                       MCRComponentState.MCC_signalmatch_root_data,
                       MCRComponentState.MCC_signalmatch_public_data,
                       MCRComponentState.MCC_signalmatch_session_data,
                       MCRComponentState.MCC_signalmatch_matlabpath_data,
                       MCRComponentState.MCC_signalmatch_classpath_data,
                       MCRComponentState.MCC_signalmatch_libpath_data,
                       MCRComponentState.MCC_signalmatch_mcr_application_options,
                       MCRComponentState.MCC_signalmatch_mcr_runtime_options,
                       MCRComponentState.MCC_signalmatch_mcr_pref_dir,
                       MCRComponentState.MCC_signalmatch_set_warning_state,
                       ctfFilePath, embeddedCtfStream, true);
      }
      else
      {
        throw new ApplicationException("MWArray assembly could not be initialized");
      }
    }


    /// <summary>
    /// Constructs a new instance of the UserAuthenticate class.
    /// </summary>
    public UserAuthenticate()
    {
    }


    #endregion Constructors

    #region Finalize

    /// <summary internal= "true">
    /// Class destructor called by the CLR garbage collector.
    /// </summary>
    ~UserAuthenticate()
    {
      Dispose(false);
    }


    /// <summary>
    /// Frees the native resources associated with this object
    /// </summary>
    public void Dispose()
    {
      Dispose(true);

      GC.SuppressFinalize(this);
    }


    /// <summary internal= "true">
    /// Internal dispose function
    /// </summary>
    protected virtual void Dispose(bool disposing)
    {
      if (!disposed)
      {
        disposed= true;

        if (disposing)
        {
          // Free managed resources;
        }

        // Free native resources
      }
    }


    #endregion Finalize

    #region Methods

    /// <summary>
    /// Provides a single output, 0-input MWArrayinterface to the channel_spectral_power
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// [data,header]=loadcsv1(file);
    /// N=size(data);
    /// N=N(2);  no of sample points
    /// T=header.records;  recording time
    /// </remarks>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray channel_spectral_power()
    {
      return mcr.EvaluateFunction("channel_spectral_power", new MWArray[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input MWArrayinterface to the channel_spectral_power
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// [data,header]=loadcsv1(file);
    /// N=size(data);
    /// N=N(2);  no of sample points
    /// T=header.records;  recording time
    /// </remarks>
    /// <param name="data">Input argument #1</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray channel_spectral_power(MWArray data)
    {
      return mcr.EvaluateFunction("channel_spectral_power", data);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the channel_spectral_power
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// [data,header]=loadcsv1(file);
    /// N=size(data);
    /// N=N(2);  no of sample points
    /// T=header.records;  recording time
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] channel_spectral_power(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "channel_spectral_power", new MWArray[]{});
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the channel_spectral_power
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// [data,header]=loadcsv1(file);
    /// N=size(data);
    /// N=N(2);  no of sample points
    /// T=header.records;  recording time
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="data">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] channel_spectral_power(int numArgsOut, MWArray data)
    {
      return mcr.EvaluateFunction(numArgsOut, "channel_spectral_power", data);
    }


    /// <summary>
    /// Provides an interface for the channel_spectral_power function in which the input
    /// and output
    /// arguments are specified as an array of MWArrays.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// [data,header]=loadcsv1(file);
    /// N=size(data);
    /// N=N(2);  no of sample points
    /// T=header.records;  recording time
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of MWArray output arguments</param>
    /// <param name= "argsIn">Array of MWArray input arguments</param>
    ///
    public void channel_spectral_power(int numArgsOut, ref MWArray[] argsOut, MWArray[] 
                             argsIn)
    {
      mcr.EvaluateFunction("channel_spectral_power", numArgsOut, ref argsOut, argsIn);
    }


    /// <summary>
    /// Provides a single output, 0-input MWArrayinterface to the feature_extract1
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray feature_extract1()
    {
      return mcr.EvaluateFunction("feature_extract1", new MWArray[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input MWArrayinterface to the feature_extract1
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <param name="file">Input argument #1</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray feature_extract1(MWArray file)
    {
      return mcr.EvaluateFunction("feature_extract1", file);
    }


    /// <summary>
    /// Provides a single output, 2-input MWArrayinterface to the feature_extract1
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <param name="file">Input argument #1</param>
    /// <param name="n">Input argument #2</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray feature_extract1(MWArray file, MWArray n)
    {
      return mcr.EvaluateFunction("feature_extract1", file, n);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the feature_extract1
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] feature_extract1(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "feature_extract1", new MWArray[]{});
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the feature_extract1
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="file">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] feature_extract1(int numArgsOut, MWArray file)
    {
      return mcr.EvaluateFunction(numArgsOut, "feature_extract1", file);
    }


    /// <summary>
    /// Provides the standard 2-input MWArray interface to the feature_extract1
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="file">Input argument #1</param>
    /// <param name="n">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] feature_extract1(int numArgsOut, MWArray file, MWArray n)
    {
      return mcr.EvaluateFunction(numArgsOut, "feature_extract1", file, n);
    }


    /// <summary>
    /// Provides an interface for the feature_extract1 function in which the input and
    /// output
    /// arguments are specified as an array of MWArrays.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// ar_coeff = calc_ar_coeff(segmented_data);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of MWArray output arguments</param>
    /// <param name= "argsIn">Array of MWArray input arguments</param>
    ///
    public void feature_extract1(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
    {
      mcr.EvaluateFunction("feature_extract1", numArgsOut, ref argsOut, argsIn);
    }


    /// <summary>
    /// Provides a single output, 0-input MWArrayinterface to the
    /// inter_hem_channel_spec_pow_diff M-function.
    /// </summary>
    /// <remarks>
    /// </remarks>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray inter_hem_channel_spec_pow_diff()
    {
      return mcr.EvaluateFunction("inter_hem_channel_spec_pow_diff", new MWArray[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input MWArrayinterface to the
    /// inter_hem_channel_spec_pow_diff M-function.
    /// </summary>
    /// <remarks>
    /// </remarks>
    /// <param name="data">Input argument #1</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray inter_hem_channel_spec_pow_diff(MWArray data)
    {
      return mcr.EvaluateFunction("inter_hem_channel_spec_pow_diff", data);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the
    /// inter_hem_channel_spec_pow_diff M-function.
    /// </summary>
    /// <remarks>
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] inter_hem_channel_spec_pow_diff(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "inter_hem_channel_spec_pow_diff", new MWArray[]{});
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the
    /// inter_hem_channel_spec_pow_diff M-function.
    /// </summary>
    /// <remarks>
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="data">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] inter_hem_channel_spec_pow_diff(int numArgsOut, MWArray data)
    {
      return mcr.EvaluateFunction(numArgsOut, "inter_hem_channel_spec_pow_diff", data);
    }


    /// <summary>
    /// Provides an interface for the inter_hem_channel_spec_pow_diff function in which
    /// the input and output
    /// arguments are specified as an array of MWArrays.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of MWArray output arguments</param>
    /// <param name= "argsIn">Array of MWArray input arguments</param>
    ///
    public void inter_hem_channel_spec_pow_diff(int numArgsOut, ref MWArray[] argsOut, 
                                      MWArray[] argsIn)
    {
      mcr.EvaluateFunction("inter_hem_channel_spec_pow_diff", numArgsOut, ref argsOut, 
                                      argsIn);
    }


    /// <summary>
    /// Provides a single output, 0-input MWArrayinterface to the loadcsv M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// IMPORTFILE(FILETOREAD1)
    /// Imports data from the specified file
    /// FILETOREAD1:  file to read
    /// </remarks>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray loadcsv()
    {
      return mcr.EvaluateFunction("loadcsv", new MWArray[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input MWArrayinterface to the loadcsv M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// IMPORTFILE(FILETOREAD1)
    /// Imports data from the specified file
    /// FILETOREAD1:  file to read
    /// </remarks>
    /// <param name="fileToRead1">Input argument #1</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray loadcsv(MWArray fileToRead1)
    {
      return mcr.EvaluateFunction("loadcsv", fileToRead1);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the loadcsv M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// IMPORTFILE(FILETOREAD1)
    /// Imports data from the specified file
    /// FILETOREAD1:  file to read
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] loadcsv(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "loadcsv", new MWArray[]{});
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the loadcsv M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// IMPORTFILE(FILETOREAD1)
    /// Imports data from the specified file
    /// FILETOREAD1:  file to read
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="fileToRead1">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] loadcsv(int numArgsOut, MWArray fileToRead1)
    {
      return mcr.EvaluateFunction(numArgsOut, "loadcsv", fileToRead1);
    }


    /// <summary>
    /// Provides an interface for the loadcsv function in which the input and output
    /// arguments are specified as an array of MWArrays.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// IMPORTFILE(FILETOREAD1)
    /// Imports data from the specified file
    /// FILETOREAD1:  file to read
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of MWArray output arguments</param>
    /// <param name= "argsIn">Array of MWArray input arguments</param>
    ///
    public void loadcsv(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
    {
      mcr.EvaluateFunction("loadcsv", numArgsOut, ref argsOut, argsIn);
    }


    /// <summary>
    /// Provides a single output, 0-input MWArrayinterface to the match M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray match()
    {
      return mcr.EvaluateFunction("match", new MWArray[]{});
    }


    /// <summary>
    /// Provides a single output, 1-input MWArrayinterface to the match M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <param name="file1">Input argument #1</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray match(MWArray file1)
    {
      return mcr.EvaluateFunction("match", file1);
    }


    /// <summary>
    /// Provides a single output, 2-input MWArrayinterface to the match M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <param name="file1">Input argument #1</param>
    /// <param name="file2">Input argument #2</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray match(MWArray file1, MWArray file2)
    {
      return mcr.EvaluateFunction("match", file1, file2);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the match M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] match(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "match", new MWArray[]{});
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the match M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="file1">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] match(int numArgsOut, MWArray file1)
    {
      return mcr.EvaluateFunction(numArgsOut, "match", file1);
    }


    /// <summary>
    /// Provides the standard 2-input MWArray interface to the match M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="file1">Input argument #1</param>
    /// <param name="file2">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] match(int numArgsOut, MWArray file1, MWArray file2)
    {
      return mcr.EvaluateFunction(numArgsOut, "match", file1, file2);
    }


    /// <summary>
    /// Provides an interface for the match function in which the input and output
    /// arguments are specified as an array of MWArrays.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// UNTITLED Summary of this function goes here
    /// Detailed explanation goes here
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of MWArray output arguments</param>
    /// <param name= "argsIn">Array of MWArray input arguments</param>
    ///
    public void match(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
    {
      mcr.EvaluateFunction("match", numArgsOut, ref argsOut, argsIn);
    }


    /// <summary>
    /// Provides a void output, 0-input MWArrayinterface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    ///
    public void storeNewFeature()
    {
      mcr.EvaluateFunction(0, "storeNewFeature", new MWArray[]{});
    }


    /// <summary>
    /// Provides a void output, 1-input MWArrayinterface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="userName">Input argument #1</param>
    ///
    public void storeNewFeature(MWArray userName)
    {
      mcr.EvaluateFunction(0, "storeNewFeature", userName);
    }


    /// <summary>
    /// Provides a void output, 2-input MWArrayinterface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="userName">Input argument #1</param>
    /// <param name="activityFile">Input argument #2</param>
    ///
    public void storeNewFeature(MWArray userName, MWArray activityFile)
    {
      mcr.EvaluateFunction(0, "storeNewFeature", userName, activityFile);
    }


    /// <summary>
    /// Provides a void output, 3-input MWArrayinterface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="userName">Input argument #1</param>
    /// <param name="activityFile">Input argument #2</param>
    /// <param name="activityType">Input argument #3</param>
    ///
    public void storeNewFeature(MWArray userName, MWArray activityFile, MWArray 
                          activityType)
    {
      mcr.EvaluateFunction(0, "storeNewFeature", userName, activityFile, activityType);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] storeNewFeature(int numArgsOut)
    {
      return mcr.EvaluateFunction(numArgsOut, "storeNewFeature", new MWArray[]{});
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="userName">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] storeNewFeature(int numArgsOut, MWArray userName)
    {
      return mcr.EvaluateFunction(numArgsOut, "storeNewFeature", userName);
    }


    /// <summary>
    /// Provides the standard 2-input MWArray interface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="userName">Input argument #1</param>
    /// <param name="activityFile">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] storeNewFeature(int numArgsOut, MWArray userName, MWArray 
                               activityFile)
    {
      return mcr.EvaluateFunction(numArgsOut, "storeNewFeature", userName, activityFile);
    }


    /// <summary>
    /// Provides the standard 3-input MWArray interface to the storeNewFeature
    /// M-function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// dir = pwd;
    /// cd(currDir);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="userName">Input argument #1</param>
    /// <param name="activityFile">Input argument #2</param>
    /// <param name="activityType">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] storeNewFeature(int numArgsOut, MWArray userName, MWArray 
                               activityFile, MWArray activityType)
    {
      return mcr.EvaluateFunction(numArgsOut, "storeNewFeature", userName, activityFile, activityType);
    }


    /// <summary>
    /// This method will cause a MATLAB figure window to behave as a modal dialog box.
    /// The method will not return until all the figure windows associated with this
    /// component have been closed.
    /// </summary>
    /// <remarks>
    /// An application should only call this method when required to keep the
    /// MATLAB figure window from disappearing.  Other techniques, such as calling
    /// Console.ReadLine() from the application should be considered where
    /// possible.</remarks>
    ///
    public void WaitForFiguresToDie()
    {
      mcr.WaitForFiguresToDie();
    }



    #endregion Methods

    #region Class Members

    private static MWMCR mcr= null;

    private bool disposed= false;

    #endregion Class Members
  }
}
