﻿namespace SignalTrainAndMatch
{
    partial class MatchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userNameLabel = new System.Windows.Forms.Label();
            this.activityTypeLabel = new System.Windows.Forms.Label();
            this.userNameTextBox = new System.Windows.Forms.TextBox();
            this.mediMatchButton = new System.Windows.Forms.Button();
            this.formCloseButton = new System.Windows.Forms.Button();
            this.mediMatchLabel = new System.Windows.Forms.Label();
            this.mathMatchLabel = new System.Windows.Forms.Label();
            this.readingMatchLabel = new System.Windows.Forms.Label();
            this.matchMediLabel = new System.Windows.Forms.Label();
            this.matchMathLabel = new System.Windows.Forms.Label();
            this.matchReadingLabel = new System.Windows.Forms.Label();
            this.mathMatchButton = new System.Windows.Forms.Button();
            this.readingMatchButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // userNameLabel
            // 
            this.userNameLabel.AutoSize = true;
            this.userNameLabel.Location = new System.Drawing.Point(32, 29);
            this.userNameLabel.Name = "userNameLabel";
            this.userNameLabel.Size = new System.Drawing.Size(60, 13);
            this.userNameLabel.TabIndex = 0;
            this.userNameLabel.Text = "User Name";
            // 
            // activityTypeLabel
            // 
            this.activityTypeLabel.AutoSize = true;
            this.activityTypeLabel.Location = new System.Drawing.Point(32, 78);
            this.activityTypeLabel.Name = "activityTypeLabel";
            this.activityTypeLabel.Size = new System.Drawing.Size(41, 13);
            this.activityTypeLabel.TabIndex = 1;
            this.activityTypeLabel.Text = "Activity";
            this.activityTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // userNameTextBox
            // 
            this.userNameTextBox.Location = new System.Drawing.Point(151, 26);
            this.userNameTextBox.Name = "userNameTextBox";
            this.userNameTextBox.Size = new System.Drawing.Size(176, 20);
            this.userNameTextBox.TabIndex = 2;
            // 
            // mediMatchButton
            // 
            this.mediMatchButton.Location = new System.Drawing.Point(151, 117);
            this.mediMatchButton.Name = "mediMatchButton";
            this.mediMatchButton.Size = new System.Drawing.Size(176, 23);
            this.mediMatchButton.TabIndex = 4;
            this.mediMatchButton.Text = "Authenticate Meditation";
            this.mediMatchButton.UseVisualStyleBackColor = true;
            this.mediMatchButton.Click += new System.EventHandler(this.signalMatchButton_Click);
            // 
            // formCloseButton
            // 
            this.formCloseButton.Location = new System.Drawing.Point(373, 24);
            this.formCloseButton.Name = "formCloseButton";
            this.formCloseButton.Size = new System.Drawing.Size(89, 23);
            this.formCloseButton.TabIndex = 5;
            this.formCloseButton.Text = "Exit";
            this.formCloseButton.UseVisualStyleBackColor = true;
            this.formCloseButton.Click += new System.EventHandler(this.formCloseButton_Click);
            // 
            // mediMatchLabel
            // 
            this.mediMatchLabel.AutoSize = true;
            this.mediMatchLabel.Location = new System.Drawing.Point(32, 122);
            this.mediMatchLabel.Name = "mediMatchLabel";
            this.mediMatchLabel.Size = new System.Drawing.Size(56, 13);
            this.mediMatchLabel.TabIndex = 6;
            this.mediMatchLabel.Text = "Meditation";
            this.mediMatchLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mathMatchLabel
            // 
            this.mathMatchLabel.AutoSize = true;
            this.mathMatchLabel.Location = new System.Drawing.Point(32, 176);
            this.mathMatchLabel.Name = "mathMatchLabel";
            this.mathMatchLabel.Size = new System.Drawing.Size(31, 13);
            this.mathMatchLabel.TabIndex = 7;
            this.mathMatchLabel.Text = "Math";
            // 
            // readingMatchLabel
            // 
            this.readingMatchLabel.AutoSize = true;
            this.readingMatchLabel.Location = new System.Drawing.Point(32, 230);
            this.readingMatchLabel.Name = "readingMatchLabel";
            this.readingMatchLabel.Size = new System.Drawing.Size(47, 13);
            this.readingMatchLabel.TabIndex = 8;
            this.readingMatchLabel.Text = "Reading";
            // 
            // matchMediLabel
            // 
            this.matchMediLabel.AutoSize = true;
            this.matchMediLabel.Location = new System.Drawing.Point(370, 117);
            this.matchMediLabel.Name = "matchMediLabel";
            this.matchMediLabel.Size = new System.Drawing.Size(92, 13);
            this.matchMediLabel.TabIndex = 9;
            this.matchMediLabel.Text = "Not authenticated";
            // 
            // matchMathLabel
            // 
            this.matchMathLabel.AutoSize = true;
            this.matchMathLabel.Location = new System.Drawing.Point(370, 176);
            this.matchMathLabel.Name = "matchMathLabel";
            this.matchMathLabel.Size = new System.Drawing.Size(92, 13);
            this.matchMathLabel.TabIndex = 10;
            this.matchMathLabel.Text = "Not authenticated";
            // 
            // matchReadingLabel
            // 
            this.matchReadingLabel.AutoSize = true;
            this.matchReadingLabel.Location = new System.Drawing.Point(370, 230);
            this.matchReadingLabel.Name = "matchReadingLabel";
            this.matchReadingLabel.Size = new System.Drawing.Size(92, 13);
            this.matchReadingLabel.TabIndex = 11;
            this.matchReadingLabel.Text = "Not authenticated";
            // 
            // mathMatchButton
            // 
            this.mathMatchButton.Location = new System.Drawing.Point(151, 171);
            this.mathMatchButton.Name = "mathMatchButton";
            this.mathMatchButton.Size = new System.Drawing.Size(176, 23);
            this.mathMatchButton.TabIndex = 12;
            this.mathMatchButton.Text = "Authenticate Math";
            this.mathMatchButton.UseVisualStyleBackColor = true;
            this.mathMatchButton.Click += new System.EventHandler(this.mathMatchButton_Click);
            // 
            // readingMatchButton
            // 
            this.readingMatchButton.Location = new System.Drawing.Point(151, 225);
            this.readingMatchButton.Name = "readingMatchButton";
            this.readingMatchButton.Size = new System.Drawing.Size(176, 23);
            this.readingMatchButton.TabIndex = 13;
            this.readingMatchButton.Text = "Authenticate Reading";
            this.readingMatchButton.UseVisualStyleBackColor = true;
            this.readingMatchButton.Click += new System.EventHandler(this.readingMatchButton_Click);
            // 
            // MatchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 289);
            this.Controls.Add(this.readingMatchButton);
            this.Controls.Add(this.mathMatchButton);
            this.Controls.Add(this.matchReadingLabel);
            this.Controls.Add(this.matchMathLabel);
            this.Controls.Add(this.matchMediLabel);
            this.Controls.Add(this.readingMatchLabel);
            this.Controls.Add(this.mathMatchLabel);
            this.Controls.Add(this.mediMatchLabel);
            this.Controls.Add(this.formCloseButton);
            this.Controls.Add(this.mediMatchButton);
            this.Controls.Add(this.userNameTextBox);
            this.Controls.Add(this.activityTypeLabel);
            this.Controls.Add(this.userNameLabel);
            this.Name = "MatchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MatchForm";
            this.Load += new System.EventHandler(this.MatchForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label userNameLabel;
        private System.Windows.Forms.Label activityTypeLabel;
        private System.Windows.Forms.TextBox userNameTextBox;
        private System.Windows.Forms.Button mediMatchButton;
        private System.Windows.Forms.Button formCloseButton;
        private System.Windows.Forms.Label mediMatchLabel;
        private System.Windows.Forms.Label mathMatchLabel;
        private System.Windows.Forms.Label readingMatchLabel;
        private System.Windows.Forms.Label matchMediLabel;
        private System.Windows.Forms.Label matchMathLabel;
        private System.Windows.Forms.Label matchReadingLabel;
        private System.Windows.Forms.Button mathMatchButton;
        private System.Windows.Forms.Button readingMatchButton;
    }
}