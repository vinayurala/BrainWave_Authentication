﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using signalmatch;
using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;
using System.Collections;
using Emotiv;

namespace SignalTrainAndMatch
{
    public partial class MatchForm : Form
    {
        string activityType;
        string userName;
        string storedFile;
        MWArray res;
        string authParam;
        System.Array ans = new double[1];
        UserAuthenticate userAuthenticateObj = new UserAuthenticate();
        //EEG_Logger p = new EEG_Logger();
        public MatchForm()
        {
            InitializeComponent();
        }

        private void MatchForm_Load(object sender, EventArgs e)
        {
            mathMatchButton.Visible = false;
            readingMatchButton.Visible = false;
            formCloseButton.Enabled = false;
        }

        private void formCloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void signalMatchButton_Click(object sender, EventArgs e)
        {
            userName = userNameTextBox.Text;
            if (userName.Equals(""))
            {
                MessageBox.Show("No username entered!!");
                return;
            }
            activityType = "Meditation";
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + userName;
            if (!(Directory.Exists(path)))
            {
                MessageBox.Show("User name \"" + userName + "\" not found!!");
                return;
            }
            else
                userNameTextBox.Enabled = false;
            string temp = activityType+"Activity1.txt";
            string filePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + userName + "\\" + temp;
            if (!(File.Exists(filePath)))
            {
                MessageBox.Show("\"" + activityType + "\" activity not trained!!Train the activity before matching");
                return;
            }
            storedFile = "MediOutfile.CSV";
            //p.record(storedFile);
            try
            {
                res = userAuthenticateObj.signalmatch(userName, storedFile, activityType);
                ans = ((MWNumericArray)res).ToVector(MWArrayComponent.Real);
                authParam = ans.GetValue(0).ToString();
                if (authParam.Equals("1"))
                {
                    mediMatchButton.Visible = false;
                    mathMatchButton.Visible = true;
                    matchMediLabel.Text = "Authenticated";
                    //formCloseButton.Enabled = true;
                }
                else
                {
                    authParam = null;
                    MessageBox.Show("Authentication Failure!!", "FAILURE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mediMatchButton.Visible = true;
                    mathMatchButton.Visible = false;
                    readingMatchButton.Visible = false;
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was some error while matching the features!!");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
            }
        }

        private void mathMatchButton_Click(object sender, EventArgs e)
        {
            activityType = "Math";
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + userName;
            string temp = activityType + "Activity1.txt";
            string filePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + userName + "\\" + temp;
            if (!(File.Exists(filePath)))
            {
                MessageBox.Show("\"" + activityType + "\" activity not trained!!Train the activity before matching");
                return;
            }
            storedFile = "MathOutfile.CSV";
            //p.record(storedFile);
            try
            {
                res = userAuthenticateObj.signalmatch(userName, storedFile, activityType);
                ans = ((MWNumericArray)res).ToVector(MWArrayComponent.Real);
                authParam = ans.GetValue(0).ToString();
                if (authParam.Equals("1"))
                {
                    mathMatchButton.Visible = false; 
                    readingMatchButton.Visible = true;
                    matchMathLabel.Text = "Authenticated";
                }
                else
                {
                    authParam = null;
                    MessageBox.Show("Authentication Failure!!", "FAILURE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mediMatchButton.Visible = true;
                    mathMatchButton.Visible = false;
                    readingMatchButton.Visible = false;
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was some error while matching the features!!");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
            }
        }

        private void readingMatchButton_Click(object sender, EventArgs e)
        {
            activityType = "Reading";
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + userName;
            string temp = activityType + "Activity1.txt";
            string filePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + userName + "\\" + temp;
            if (!(File.Exists(filePath)))
            {
                MessageBox.Show("\"" + activityType + "\" activity not trained!!Train the activity before matching");
                return;
            }
            storedFile = "ReadingOutfile.CSV";
            //p.record(storedFile);
            try
            {
                res = userAuthenticateObj.signalmatch(userName, storedFile, activityType);
                ans = ((MWNumericArray)res).ToVector(MWArrayComponent.Real);
                authParam = ans.GetValue(0).ToString();
                if (authParam.Equals("1"))
                {
                    readingMatchButton.Visible = false;
                    matchReadingLabel.Text = "Authenticated";
                    MessageBox.Show("Authentication Success!!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    formCloseButton.Enabled = true;
                }
                else
                {
                    authParam = null;
                    MessageBox.Show("Authentication Failure!!", "FAILURE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    formCloseButton.Enabled = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was some error while matching the features!!");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
            }
        }

    }
}
