/*
 * Created by SharpDevelop.
 * User: Vinay K Urala
 * Date: 5/6/2010
 * Time: 4:14 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Text;
using Emotiv;
using signalmatch;
using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace SignalTrainAndMatch
{
	/// <summary>
	/// Description of TrainingForm.
	/// </summary>
	public partial class TrainingForm : Form
	{
		string activityType;
		string userName;
		string storedFile;
		UserAuthenticate userAuthObj = new UserAuthenticate();
		//string currDir = Environment.CurrentDirectory;
		//EEG_Logger p = new EEG_Logger();
		public TrainingForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void ActivityTypeLabelClick(object sender, EventArgs e)
		{
			
		}
		
		void TrainingFormLoad(object sender, EventArgs e)
		{
            trainReadingButton.Visible = false;
            trainMathButton.Visible = false;
            trainFormExitButton.Enabled = false;
		}
		
		void TrainFormExitButtonClick(object sender, EventArgs e)
		{
			this.Close();
		}
		
		void TrainStartButtonClick(object sender, EventArgs e)
		{
			if(userNameTextBox.TextLength == 0)
			{
				MessageBox.Show("No username entered!!");
				return;
			}
            else
                userNameTextBox.Enabled = false;
			userName = userNameTextBox.Text;
			activityType = "Meditation";
			storedFile = "MediOutfile.CSV";
			//p.record(storedFile);
			try{
				userAuthObj.storeNewFeature(userName , storedFile , activityType);
				MessageBox.Show("Training Completed successfully!!");
                mediTrainedlabel.Text = "Completed";
                trainMediButton.Visible = false;
                trainMathButton.Visible = true;
			}
			catch (Exception ex)
			{
				MessageBox.Show("There was some error while extracting features");
				MessageBox.Show(ex.Message);
				MessageBox.Show(ex.StackTrace);
				Application.Exit();
			}
		}

        private void trainMathButton_Click(object sender, EventArgs e)
        {
            activityType = "Math";
            storedFile = "MathOutfile.CSV";
            //p.record(storedFile);
            try
            {
                userAuthObj.storeNewFeature(userName, storedFile, activityType);
                MessageBox.Show("Training Completed successfully!!");
                mathTrainedLabel.Text = "Completed";
                trainMathButton.Visible = false;
                trainReadingButton.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was some error while extracting features");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
                Application.Exit();
            }
        }

        private void trainReadingButton_Click(object sender, EventArgs e)
        {
            activityType = "Reading";
            storedFile = "ReadingOutfile.CSV";
            //p.record(storedFile);
            try
            {
                userAuthObj.storeNewFeature(userName, storedFile, activityType);
                MessageBox.Show("Training Completed successfully!!");
                readingTrainedLabel.Text = "Completed";
                trainReadingButton.Visible = false;
                trainFormExitButton.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was some error while extracting features");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
                Application.Exit();
            }
        }
	}
}
