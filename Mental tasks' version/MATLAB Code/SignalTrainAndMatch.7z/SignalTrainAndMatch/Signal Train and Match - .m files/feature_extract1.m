function [feature_set] = feature_extract1(file,n)
    data=loadcsv(file);
    segmented_data=data(:,(1280*(n-1)+1):1280*n);
    %ar_coeff = calc_ar_coeff(segmented_data);
    channel_spec_pow = channel_spectral_power(segmented_data);
    inter_channel_spec_power = inter_hem_channel_spec_pow_diff(segmented_data);
    feature_set = horzcat(channel_spec_pow , inter_channel_spec_power);  
end

