function inter_channel_spec_power = inter_hem_channel_spec_pow_diff(data)
channel_spec_pow = channel_spectral_power(data);
inter_channel_spec_power = zeros(14,6);
for i=1:7
    p1=channel_spec_pow(i,:);
    p2=channel_spec_pow(15-i,:);
    
inter_channel_spec_power(i,:)=abs((p1-p2)./(p1+p2));
end
for i=1:7
    for j=4:6
       inter_channel_spec_power(i,j) = 0;
    end
end
for i=8:14
    inter_channel_spec_power(i,:)=0;
end
end