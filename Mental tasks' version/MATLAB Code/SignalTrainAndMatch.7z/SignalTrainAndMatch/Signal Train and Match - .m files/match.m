function [ authparam ] = match(file1,file2)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

feature_set=feature_extract1(file1,1);
[lambda,q]=pca(feature_set,3);
feature_set=feature_extract1(file2,1);
[sigma,p]=pca(feature_set,3);
S=0;

%%Finding similarity between Eigen vectors
for i=1:3
    for j=1:3
       S=S+(lambda(i)/sqrt(lambda(1)^2+lambda(2)^2+lambda(3)^2))*(sigma(j)/sqrt(sigma(1)^2+sigma(2)^2+sigma(3)^2))*(abs(q(:,i)'*p(:,j))^2);
    end
end
disp(S);
        if(S>=.78)
            %file1
            feature_set=feature_extract1(file1,2);
            [lambda,q]=pca(feature_set,3);
                      
            %file2
            feature_set=feature_extract1(file2,2);
            [sigma,p]=pca(feature_set,3);
            
            S=0;
            for i=1:3
                for j=1:3
                   S=S+(lambda(i)/sqrt(lambda(1)^2+lambda(2)^2+lambda(3)^2))*(sigma(j)/sqrt(sigma(1)^2+sigma(2)^2+sigma(3)^2))*(abs(q(:,i)'*p(:,j))^2);
                end
            end
            if(S>=.78)
                authparam = 1;
                return;
            else
                authparam = 0;
                return;
            end
        else
            authparam = 0;
            return;
        end
end













