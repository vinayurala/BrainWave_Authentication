function storeNewFeature(userName , activityFile , activityType)
if(nargin ~= 3)
    error('Usage: storeNewFeature(username(string) , activity file(string with .CSV extension) , activityType(string)');
end
%dir = pwd;
%cd(currDir);
x = exist(userName , 'dir');
if (x == 0)
    mkdir(userName);
end
x1 = feature_extract1(activityFile , 1);
x2 = feature_extract1(activityFile , 2);
fileName1 = strcat(activityType , '1.txt');
fileName2 = strcat(activityType , '2.txt');
cd(userName);
csvwrite(fileName1 , x1);
csvwrite(fileName2 , x2);
cd ..;
%cd(dir);
end