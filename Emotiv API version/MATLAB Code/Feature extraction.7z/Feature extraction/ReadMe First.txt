	I have written a set of modules and stolen a few to extract features from a given EEG signal.

These modules are only to extract features and "not for comparing them". Comparsion, as of now, can be 

done manually by calculating either Euclidean distance or Manhattan disatnce. Code for automated 

feature comparsion can be written using concepts of data mining (I had nearest neighbor classifier

algorithm in my mind), but it can wait. I just want to confirm that this method works 

properly for any EEG signal.

	
	This method extracts 3 features(6 AR co-efficients, Approximate Entropy and Power Spectral

Entropy). Another feature has which has to be extracted is Channel Spectral Power which I presume

Dharaini can do it(@Dharaini: You have already written the code for Channel Spectral Power in 

newmatch.m. The only thing that you have to do is rewrite this module with the EDF/EEG file as a

parameter to it). I have included all the references which I used to either write the code or steal

it. Its specified at the beginning of every *.m file 


	If you want to compare features of 2 signals, then you can do the following:

	i)Run feature_extract function passing first file as a parameter

	ii)Copy the ans variable to another variable, say x.

	iii)Repeat the first 2 steps.Let second variable be y.

	iv)Calculate Euclidean distance as a)xx=x.*x b)yy=y.*y c)eucxy = sqrt(abs(xx-yy))  

	v)Compare the euclidean distances to classify the EEG signals.
 